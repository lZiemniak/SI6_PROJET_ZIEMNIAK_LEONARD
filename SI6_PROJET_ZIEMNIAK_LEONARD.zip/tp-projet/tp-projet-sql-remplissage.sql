use Projet ;

insert into User values(1 , 'ZIEMNIAK' , 'Léonard' , 5000 , 'admin' , 'l22022000') ;
insert into User values(2 , 'GEOFFRON' , 'Thomas' , 200 , 'tgeof' , 'azerty');
insert into User values(3 , 'MASSICOT' , 'Lucas' , 50000 , 'lmass' , 'azerty');


