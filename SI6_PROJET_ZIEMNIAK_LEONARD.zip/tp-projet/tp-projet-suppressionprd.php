<?php
session_start();
	$idvoiture = $_POST['id1'];
	echo $idvoiture;
	
try{
	$pdo = new PDO("mysql:host=localhost;dbname=Projet", "root", "");
	$pdo -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	$pdostat=$pdo->prepare("DELETE FROM Voiture Where id_voiture = :id");
	
	$pdostat->execute(array(':id' => $idvoiture));
	
	
	header("Location:tp-projet-accueil.html");
}
catch(PDOException $e){
	echo "Error :" .$e->getMessage();
	die();
}

?>
