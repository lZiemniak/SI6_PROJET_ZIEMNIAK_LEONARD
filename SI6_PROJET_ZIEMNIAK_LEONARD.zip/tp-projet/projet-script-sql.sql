drop database if exists Projet ;
create database if not exists Projet ;
use Projet ;

Create table User(
id_user int,
nom_user varchar(30),
prenom_user varchar(30),
porteFeuille int,
identifiant varchar(20),
mdp varchar(20),
primary key(id_user)
);

Create table Voiture(
id_voiture int,
serie int,
motorisation double,
chassis varchar(20),
Puissance int,
longueur float ,
largeur float,
coffre int,
prixSerie float,
qteDispo int,
primary key(id_voiture)
);
