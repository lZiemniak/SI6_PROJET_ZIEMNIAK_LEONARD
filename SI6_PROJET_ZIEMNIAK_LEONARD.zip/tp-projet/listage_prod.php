<!DOCTYPE html>
<html>
	<head>
		<title>Categorie</title>
		<link href="bmw.css" rel="stylesheet">
	</head>
	<body class="lstprod">
		<header>
		<div class="entete">
			<nav>
				<ul>
					<li><a href="listage_prod.php">Liste Véhicules</a></li>
					<li><a href="tp-projet-ajout.html">Ajout d'un véhicule</a></li>
					<li><a href="tp-projet-suppressionprd.html">Suppression d'un véhicule</a></li>
					<li><a href="tp-projet-pg-Co.html">Déconnexion</a></li>
				</ul>
				<img class="logo" src="images/Logo-BMW.png" width="230" height="100" />
			</nav>
		</div>
		</header>
		<?php 
			$cnx = new PDO("mysql:host=localhost;dbname=Projet", "root","");

		?>

		<form action="tp-projet-categorieProd.php" method="POST"> 

			<label class="cat" for="categorie">Carosserie(Catégorie) :</label>
			<select class="add" name="categorie" id="categorie">
					<OPTION>Coupé
					<OPTION>Cabriolet
					<OPTION>Compact
					<OPTION>Berline
					<OPTION>Sportive
					<OPTION>SUV
					<OPTION>Limousine

			</select>


			<input class="btnCo" type= "submit" value= "Selectionner"> </br>
			
			<a href="tp-projet-accueil.html"><input class="btnCo" type="button" value="Retour"></a>


		</form>

		</body>
</html>
