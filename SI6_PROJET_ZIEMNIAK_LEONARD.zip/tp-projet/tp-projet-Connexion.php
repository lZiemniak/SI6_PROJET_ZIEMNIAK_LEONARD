<?php
session_start();

$login = $_POST['login'];
$passwd = $_POST['mdp'];


#if(isset($_POST['login'])){
	$pdo = new PDO('mysql:host=localhost;dbname=Projet', 'root', '');
	$pdoreq = $pdo->query("SELECT identifiant,mdp from User where identifiant = '" .$login. "'  and mdp = '".$passwd."'") ;
	$pdoreq -> setFetchMode(PDO::FETCH_ASSOC);
	echo $passwd . $login ;
	foreach($pdoreq as $ligne){
		echo $ligne['identifiant']."   ".$ligne['mdp'];	
		if($login == $ligne['identifiant']){
			if($passwd == $ligne['mdp']){
				header('Location:tp-projet-accueil.html');
				
			}
			echo "Le mot de passe est incorrect";
		}
		echo "L'identifiant est incorrect";
	}
	echo "erreur de base de données";
	
#}
#echo "Les champs spécifiés ne sont pas remplis";

die();
?>
