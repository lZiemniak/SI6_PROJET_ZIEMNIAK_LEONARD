<?php
session_start();
	$idvoiture = $_POST['id'];
	$serie = $_POST['serie'];
	$motorisation =$_POST['motorisation'];
	$chassis = $_POST['chassis'];
	$Puissance = $_POST['puissance'];
	$longueur = $_POST['longueur'];
	$largeur = $_POST['largeur'];
	$coffre = $_POST['coffre'];
	$prixSerie = $_POST['prixS'];
	$qteDispo = $_POST['qte'];

try{
	$pdo = new PDO('mysql:host=localhost;dbname=Projet', 'root', '');
	$pdo -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	$req = "insert into Voiture(id_voiture, serie, motorisation, chassis, Puissance, longueur, largeur, coffre, prixSerie, qteDispo) values(?,?,?,?,?,?,?,?,?,?)" ;
	$pdoreq = $pdo->prepare($req);
	$pdoreq->execute([$idvoiture,$serie,$motorisation,$chassis,$Puissance,$longueur,$largeur,$coffre,$prixSerie,$qteDispo]);
	
	header('location:tp-projet-accueil.html');
}
catch(PDOException $e){
	echo "Error :" .$e->getMessage();
	die();
}

?>
