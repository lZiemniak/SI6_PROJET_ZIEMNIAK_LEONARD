<!DOCTYPE html>
<html>
	<head>
		<title>Produit</title>
		<link href="bmw.css" rel="stylesheet">
	</head>
	<body class="cate">
		<header>
		<div class="entete">
			<nav>
				<ul>
					<li><a href="listage_prod.php">Liste Véhicules</a></li>
					<li><a href="tp-projet-ajout.html">Ajout d'un véhicule</a></li>
					<li><a href="tp-projet-suppressionprd.html">Suppression d'un véhicule</a></li>
					<li><a href="tp-projet-pg-Co.html">Déconnexion</a></li>
				</ul>
				<img class="logo" src="images/Logo-BMW.png" width="230" height="100" />
			</nav>
		</div>
	</header>
		<h1>Voitures par Carrosseries :</h1>

	<?php 
	
	$cat = $_POST['categorie'];


	try{
		
		$pdo = new PDO("mysql:host=localhost;dbname=Projet", "root","");
		
		$pdoreq = $pdo->query("SELECT * FROM Voiture WHERE chassis = '" . $cat . "'") ;
		$pdoreq -> setFetchMode(PDO::FETCH_ASSOC);
		
		foreach ($pdoreq as $uneVoit){	
			
			echo "<table class=\"catégorie\">" ;
			echo "<tr>";
			echo "<td>ID de la voiture :</td>";
			echo "<td>Série :</td>";
			echo "<td>Motorisation :</td>";
			echo "<td>Carosserie :</td>";
			echo "<td>Puissance :</td>";
			echo "<td>Longueur :</td>";
			echo "<td>Largeur :</td>";
			echo "<td>Coffre :</td>";
			echo "<td>Prix de série :</td>";
			echo "<td>Quantité disponible :</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td><h4>" . $uneVoit['id_voiture'] . "</h4></td>";
			echo "<td><h4>" . $uneVoit['serie'] . "</h4></td>";
			echo "<td><h4>" . $uneVoit['motorisation'] . "</h4></td>";
			echo "<td><h4>" . $uneVoit['chassis'] . "</h4></td>";
			echo "<td><h4>" . $uneVoit['Puissance'] . "</h4></td>";
			echo "<td><h4>" . $uneVoit['longueur'] . "</h4></td>";
			echo "<td><h4>" . $uneVoit['largeur'] . "</h4></td>";
			echo "<td><h4>" . $uneVoit['coffre'] . "</h4></td>";
			echo "<td><h4>" . $uneVoit['prixSerie'] . "</h4></td>";
			echo "<td><h4>" . $uneVoit['qteDispo'] . "</h4></td>";
			echo "</tr>";
			echo "</table>";

		

		}
	}
	catch(PDOException $e){
		echo $rqtSuppr . "<br>" . $e->getMessage();
	}
	?>

		
	<p> <a href="tp-projet-accueil.html"><input class="btnCo" type="button" value="Retour"></a></p>

	</body>
</html>

	
